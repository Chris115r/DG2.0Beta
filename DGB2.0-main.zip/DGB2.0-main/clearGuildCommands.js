require('dotenv').config();
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');

const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;
const token = process.env.DISCORD_TOKEN;

const rest = new REST({ version: '9' }).setToken(token);

(async () => {
  try {
    console.log('Started clearing application (/) commands in guild.');

    await rest.put(
      Routes.applicationGuildCommands(clientId, guildId),
      { body: [] }
    );

    console.log('Successfully cleared application (/) commands in guild.');
  } catch (error) {
    console.error(error);
  }
})();
