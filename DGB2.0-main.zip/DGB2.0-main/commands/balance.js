// Path: DG-2.0/commands/balance.js

const { SlashCommandBuilder } = require('@discordjs/builders');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription('Shows the current balance of the user'),
    async execute(interaction) {
        const players = JSON.parse(fs.readFileSync('./data/players.json'));
        const userId = interaction.user.id;

        if (!players[userId]) {
            return interaction.reply({ content: 'You are not registered yet.', ephemeral: true });
        }

        const balance = players[userId].balance;
        return interaction.reply({ content: `Your current balance is ${balance}.`, ephemeral: true });
    },
};
