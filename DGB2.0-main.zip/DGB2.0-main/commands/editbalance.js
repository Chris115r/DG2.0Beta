// Path: DG-2.0/commands/editbalance.js

const { SlashCommandBuilder } = require('@discordjs/builders');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('editbalance')
        .setDescription('Allows an admin to edit a user\'s balance')
        .addUserOption(option => option.setName('user').setDescription('User to edit').setRequired(true))
        .addIntegerOption(option => option.setName('amount').setDescription('Amount to add or subtract').setRequired(true)),
    async execute(interaction) {
        // Check if the user has the ADMINISTRATOR permission
        if (!interaction.member.permissions.has('ADMINISTRATOR')) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        // Retrieve options
        const user = interaction.options.getUser('user');
        const amount = interaction.options.getInteger('amount');
        const playersPath = path.resolve('./data/players.json');

        // Read existing player data
        const players = fs.existsSync(playersPath) ? JSON.parse(fs.readFileSync(playersPath)) : {};

        // Check if the target user is registered
        if (!players[user.id]) {
            return interaction.reply({ content: 'The user is not registered.', ephemeral: true });
        }

        // Update the user's balance
        players[user.id].balance += amount;

        // Save updated player data
        fs.writeFileSync(playersPath, JSON.stringify(players, null, 2));

        // Send confirmation message
        await interaction.reply({ content: `The balance of ${user.username} has been updated by ${amount}. New balance: ${players[user.id].balance}`, ephemeral: true });

        // Update leaderboard
        const updateLeaderboard = require('../utils/updateLeaderboard');
        updateLeaderboard(interaction.client);
    },
};
