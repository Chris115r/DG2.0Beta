// Path: DG-2.0/commands/help.js

const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Provides information about the available commands'),
    async execute(interaction) {
        const helpEmbed = new MessageEmbed()
            .setTitle('Help - Available Commands')
            .setDescription('Here is a list of all available commands and their usage:')
            .setColor('BLUE')
            .addFields(
                { name: '/register', value: 'Registers a user with an initial balance. Example: `/register`' },
                { name: '/trade', value: 'Initiates a new trade. Example: `/trade symbol:<symbol> amount:<amount> takeprofit:<takeprofit> stoploss:<stoploss>`' },
                { name: '/editbalance', value: 'Edits the balance of a user. Example: `/editbalance @username <amount>`' },
                { name: '/balance', value: 'Checks your current balance. Example: `/balance`' },
                { name: '/help', value: 'Provides information about the available commands. Example: `/help`' }
            )
            .setFooter({ text: 'Use /help to get this message again' });

        await interaction.reply({ embeds: [helpEmbed], ephemeral: true });
    },
};
