// Path: DG-2.0/commands/portfolio.js

const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageSelectMenu, MessageButton, MessageEmbed } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('portfolio')
        .setDescription('Displays all open trades for the user'),
    async execute(interaction) {
        const userId = interaction.user.id;
        const tradesPath = path.resolve('./data/trades.json');

        // Check if the trades file exists
        if (!fs.existsSync(tradesPath)) {
            return interaction.reply({ content: 'No trades found.', ephemeral: true });
        }

        // Read and parse the trades file
        const tradesData = fs.readFileSync(tradesPath, 'utf-8');
        const trades = JSON.parse(tradesData);

        // Filter trades by the user's ID
        const userTrades = Object.entries(trades).filter(([tradeId, trade]) => trade.userId === userId);

        // Check if the user has any open trades
        if (userTrades.length === 0) {
            return interaction.reply({ content: 'You have no open trades.', ephemeral: true });
        }

        // Create a dropdown menu with the user's trades
        const tradeOptions = userTrades.map(([tradeId, trade]) => ({
            label: `Trade ID: ${tradeId} - ${trade.symbol}`,
            description: `Amount: ${trade.amount} - Date of Entry: ${new Date(trade.timeOpened).toLocaleString()}`,
            value: tradeId,
        }));

        const tradeSelectMenu = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('select_trade')
                    .setPlaceholder('Select a trade')
                    .addOptions(tradeOptions)
            );

        await interaction.reply({ content: 'Select a trade from the dropdown menu:', components: [tradeSelectMenu], ephemeral: true });

        // Create a collector to handle the user's trade selection
        const filter = i => i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 300000 }); // 5 minutes

        collector.on('collect', async i => {
            if (i.customId === 'select_trade') {
                const tradeId = i.values[0];
                const trade = trades[tradeId];

                // Display the trade details with a button to close the trade
                const tradeEmbed = new MessageEmbed()
                    .setTitle('Trade Details')
                    .setDescription(`
                        **Trade ID**: ${tradeId}
                        **Trade Type**: ${trade.type.charAt(0).toUpperCase() + trade.type.slice(1)}
                        **Symbol**: ${trade.symbol}
                        **Amount**: ${trade.amount}
                        **Take Profit**: ${trade.takeProfit ? trade.takeProfit : 'N/A'}
                        **Stop Loss**: ${trade.stopLoss ? trade.stopLoss : 'N/A'}
                        **Date of Entry**: ${new Date(trade.timeOpened).toLocaleString()}
                    `)
                    .setColor(trade.type === 'buy' ? 'GREEN' : 'RED');

                const closeButton = new MessageActionRow()
                    .addComponents(
                        new MessageButton()
                            .setCustomId('close_trade')
                            .setLabel('Close Trade')
                            .setStyle('DANGER')
                    );

                await i.update({ embeds: [tradeEmbed], components: [closeButton], ephemeral: true });

                const closeCollector = i.channel.createMessageComponentCollector({ filter, time: 300000 }); // 5 minutes

                closeCollector.on('collect', async buttonInteraction => {
                    if (buttonInteraction.customId === 'close_trade') {
                        // Log the closed trade to the trade logs channel
                        const tradeLogsChannel = interaction.guild.channels.cache.get(process.env.TRADE_LOGS_CHANNEL_ID);
                        const closeTime = new Date().toISOString();

                        if (tradeLogsChannel) {
                            const tradeLogEmbed = new MessageEmbed()
                                .setTitle('Trade Closed')
                                .setDescription(`
                                    **User**: <@${trade.userId}>
                                    **Trade ID**: ${tradeId}
                                    **Trade Type**: ${trade.type.charAt(0).toUpperCase() + trade.type.slice(1)}
                                    **Symbol**: ${trade.symbol}
                                    **Amount**: ${trade.amount}
                                    **Take Profit**: ${trade.takeProfit ? trade.takeProfit : 'N/A'}
                                    **Stop Loss**: ${trade.stopLoss ? trade.stopLoss : 'N/A'}
                                    **Date of Entry**: ${new Date(trade.timeOpened).toLocaleString()}
                                    **Date Closed**: ${new Date(closeTime).toLocaleString()}
                                `)
                                .setColor(trade.type === 'buy' ? 'GREEN' : 'RED');

                            tradeLogsChannel.send({ embeds: [tradeLogEmbed] });
                        }

                        // Remove the trade from trades.json
                        delete trades[tradeId];

                        try {
                            fs.writeFileSync(tradesPath, JSON.stringify(trades, null, 2));
                        } catch (error) {
                            console.error('Error writing to trades.json:', error);
                        }

                        await buttonInteraction.update({ content: 'Trade closed.', embeds: [], components: [], ephemeral: true });
                        closeCollector.stop();
                    }
                });

                closeCollector.on('end', collected => {
                    if (collected.size === 0) {
                        i.editReply({ content: 'Trade close timed out. Please initiate the trade again.', embeds: [], components: [], ephemeral: true });
                    }
                });

                collector.stop();
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.editReply({ content: 'Trade selection timed out. Please initiate the trade again.', components: [], ephemeral: true });
            }
        });
    },
};
