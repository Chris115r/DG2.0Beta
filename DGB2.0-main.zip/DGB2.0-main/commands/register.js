// Path: DG-2.0/commands/register.js

const { SlashCommandBuilder } = require('@discordjs/builders');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('register')
        .setDescription('Registers a user with an initial balance'),
    async execute(interaction) {
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const role = interaction.guild.roles.cache.find(r => r.name === 'Paper Trader');

        // Check if the user already has the "Paper Trader" role
        if (member.roles.cache.has(role.id)) {
            return interaction.reply({ content: 'You are already registered.', ephemeral: true });
        }

        const playersPath = './data/players.json';
        const players = fs.existsSync(playersPath) ? JSON.parse(fs.readFileSync(playersPath)) : {};
        const userId = interaction.user.id;
        const initialBalance = 100000; // Example initial balance

        // Register the user
        players[userId] = { balance: initialBalance };

        fs.writeFileSync(playersPath, JSON.stringify(players, null, 2));
        await interaction.reply('You have been registered with an initial balance of 100,000.');

        // Assign the "Paper Trader" role to the user
        await member.roles.add(role);

        // Update leaderboard
        const updateLeaderboard = require('../utils/updateLeaderboard');
        updateLeaderboard(interaction.client);

        // Send a welcome message to the announcements channel
        const announcementChannel = interaction.guild.channels.cache.get(process.env.ANNOUNCEMENT_CHANNEL_ID);
        if (announcementChannel) {
            announcementChannel.send(`Welcome ${interaction.user.username}! You have been registered with an initial balance of 100,000. Use /help to get started.`);
        }
    },
};
