const fs = require('fs');
const path = require('path');
const { SlashCommandBuilder } = require('@discordjs/builders');

const PLAYERS_FILE = path.join(__dirname, '../data/players.json');
const TRADES_FILE = path.join(__dirname, '../data/trades.json');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reset')
    .setDescription('Resets all player data and trades.'),
  async execute(interaction) {
    // Check if the user has admin privileges
    const member = await interaction.guild.members.fetch(interaction.user.id);
    if (!member.permissions.has('ADMINISTRATOR')) {
      return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
    }

    // Clear players.json
    if (fs.existsSync(PLAYERS_FILE)) {
      fs.writeFileSync(PLAYERS_FILE, JSON.stringify({}, null, 2), 'utf8');
    }

    // Clear trades.json
    if (fs.existsSync(TRADES_FILE)) {
      fs.writeFileSync(TRADES_FILE, JSON.stringify([], null, 2), 'utf8');
    }

    // Respond to the user
    await interaction.reply('All player data and trades have been reset.');
  }
};
