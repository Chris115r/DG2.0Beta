// Path: DG-2.0/commands/trade.js

const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageSelectMenu, MessageButton, MessageEmbed } = require('discord.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('trade')
        .setDescription('Initiates a new trade')
        .addStringOption(option => option.setName('symbol').setDescription('Stock symbol').setRequired(true))
        .addIntegerOption(option => option.setName('amount').setDescription('Amount to trade').setRequired(true))
        .addNumberOption(option => option.setName('takeprofit').setDescription('Take profit level').setRequired(false))
        .addNumberOption(option => option.setName('stoploss').setDescription('Stop loss level').setRequired(false)),
    async execute(interaction) {
        const member = await interaction.guild.members.fetch(interaction.user.id);
        const role = interaction.guild.roles.cache.find(r => r.name === 'Paper Trader');

        // Check if the user has the "Paper Trader" role
        if (!member.roles.cache.has(role.id)) {
            return interaction.reply({ content: 'You must be registered as a Paper Trader to execute trades.', ephemeral: true });
        }

        const symbol = interaction.options.getString('symbol');
        const amount = interaction.options.getInteger('amount');
        const takeProfit = interaction.options.getNumber('takeprofit');
        const stopLoss = interaction.options.getNumber('stoploss');

        // Create the dropdown menu for trade type selection
        const tradeTypeRow = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('select_trade_type')
                    .setPlaceholder('Select trade type')
                    .addOptions([
                        {
                            label: 'Buy',
                            description: 'Execute a buy trade',
                            value: 'buy',
                        },
                        {
                            label: 'Sell',
                            description: 'Execute a sell trade',
                            value: 'sell',
                        },
                    ]),
            );

        await interaction.reply({ content: 'Please select the type of trade you want to execute.', components: [tradeTypeRow], ephemeral: true });

        // Create a collector to handle the user's selection
        const filter = i => i.user.id === interaction.user.id;
        const collector = interaction.channel.createMessageComponentCollector({ filter, time: 300000 }); // 5 minutes

        collector.on('collect', async i => {
            if (i.customId === 'select_trade_type') {
                const tradeType = i.values[0];
                const color = tradeType === 'buy' ? 'GREEN' : 'RED';

                // Confirm the trade details with the user
                const confirmationEmbed = new MessageEmbed()
                    .setTitle('Trade Confirmation')
                    .setDescription(`
                        Trade Type: ${tradeType.charAt(0).toUpperCase() + tradeType.slice(1)}
                        Symbol: ${symbol}
                        Amount: ${amount}
                        ${takeProfit ? `Take Profit: ${takeProfit}` : ''}
                        ${stopLoss ? `Stop Loss: ${stopLoss}` : ''}
                    `)
                    .setColor(color);

                const confirmationRow = new MessageActionRow()
                    .addComponents(
                        new MessageButton()
                            .setCustomId('confirm_trade')
                            .setLabel('Confirm')
                            .setStyle('SUCCESS'),
                        new MessageButton()
                            .setCustomId('cancel_trade')
                            .setLabel('Cancel')
                            .setStyle('DANGER'),
                    );

                await i.update({ embeds: [confirmationEmbed], components: [confirmationRow] });

                const confirmationCollector = i.channel.createMessageComponentCollector({ filter, time: 300000 }); // 5 minutes

                confirmationCollector.on('collect', async buttonInteraction => {
                    if (buttonInteraction.customId === 'confirm_trade') {
                        // Execute the trade
                        const tradesPath = path.resolve('./data/trades.json');
                        let trades = {};

                        // Read the existing trades from the file
                        if (fs.existsSync(tradesPath)) {
                            const tradesData = fs.readFileSync(tradesPath, 'utf-8');
                            try {
                                trades = JSON.parse(tradesData);
                            } catch (error) {
                                console.error('Error parsing trades.json:', error);
                            }
                        }

                        // Generate the next trade ID
                        const tradeIds = Object.keys(trades).map(id => parseInt(id));
                        const nextTradeId = tradeIds.length ? Math.max(...tradeIds) + 1 : 1;

                        // Add the new trade
                        trades[nextTradeId] = {
                            userId: interaction.user.id,
                            username: interaction.user.username,
                            type: tradeType,
                            symbol,
                            amount,
                            takeProfit,
                            stopLoss,
                            timeOpened: new Date().toISOString(),
                        };

                        try {
                            // Attempt to write the trade data to trades.json
                            fs.writeFileSync(tradesPath, JSON.stringify(trades, null, 2));
                        } catch (error) {
                            console.error('Error writing to trades.json:', error);
                        }

                        // Log the trade in the trade logs channel
                        const tradeLogsChannel = interaction.guild.channels.cache.get(process.env.TRADE_LOGS_CHANNEL_ID);
                        if (tradeLogsChannel) {
                            const tradeLogEmbed = new MessageEmbed()
                                .setTitle('New Trade Executed')
                                .setDescription(`
                                    User: <@${interaction.user.id}>
                                    Trade Type: ${tradeType.charAt(0).toUpperCase() + tradeType.slice(1)}
                                    Symbol: ${symbol}
                                    Amount: ${amount}
                                    ${takeProfit ? `Take Profit: ${takeProfit}` : ''}
                                    ${stopLoss ? `Stop Loss: ${stopLoss}` : ''}
                                    Time Opened: ${new Date().toLocaleString()}
                                `)
                                .setColor(color);

                            tradeLogsChannel.send({ embeds: [tradeLogEmbed] });
                        }

                        await buttonInteraction.update({ content: 'Your trade has been executed.', embeds: [], components: [], ephemeral: true });

                        // Update the leaderboard
                        const updateLeaderboard = require('../utils/updateLeaderboard');
                        updateLeaderboard(interaction.client);

                        confirmationCollector.stop();
                    } else if (buttonInteraction.customId === 'cancel_trade') {
                        await buttonInteraction.update({ content: 'Trade cancelled.', embeds: [], components: [], ephemeral: true });
                        confirmationCollector.stop();
                    }
                });

                collector.stop();
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                interaction.followUp({ content: 'Trade selection timed out. Please initiate the trade again.', ephemeral: true });
            }
        });
    },
};
