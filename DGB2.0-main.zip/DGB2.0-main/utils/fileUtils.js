const fs = require('fs');
const path = require('path');

const PLAYERS_FILE = path.join(__dirname, '../data/players.json');
const TRADES_FILE = path.join(__dirname, '../data/trades.json');

const ensureDataFilesExist = () => {
  if (!fs.existsSync(PLAYERS_FILE)) {
    fs.writeFileSync(PLAYERS_FILE, JSON.stringify({}, null, 2));
    console.log('Created players.json');
  }
  if (!fs.existsSync(TRADES_FILE)) {
    fs.writeFileSync(TRADES_FILE, JSON.stringify([], null, 2));
    console.log('Created trades.json');
  }
};

module.exports = { ensureDataFilesExist };
