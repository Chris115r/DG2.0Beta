const { MessageEmbed } = require('discord.js');

function createEmbedMessage(title, description, footerText, color = '#FFD700') {
  return new MessageEmbed()
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: footerText, iconURL: 'https://discord.com/assets/2c21aeda16de354ba5334551a883b481.png' })
    .setColor(color);
}

function createConfirmationMessage(title, description) {
  return new MessageEmbed()
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: 'Confirm your action', iconURL: 'https://discord.com/assets/2c21aeda16de354ba5334551a883b481.png' })
    .setColor('#FFFF00');
}

function createLeaderboardMessage(players, lastUpdated) {
  let description = players.map((player, index) => {
    let medal = '';
    if (index === 0) medal = ':first_place:';
    else if (index === 1) medal = ':second_place:';
    else if (index === 2) medal = ':third_place:';
    return `${medal} <@${player.id}>: $${player.balance}`;
  }).join('\n');

  return new MessageEmbed()
    .setTitle(':trophy: Leaderboard :trophy:')
    .setDescription(description)
    .setFooter({ text: `Last updated: ${lastUpdated}`, iconURL: 'https://discord.com/assets/2c21aeda16de354ba5334551a883b481.png' })
    .setColor('#FFD700');
}

module.exports = {
  createEmbedMessage,
  createConfirmationMessage,
  createLeaderboardMessage
};
