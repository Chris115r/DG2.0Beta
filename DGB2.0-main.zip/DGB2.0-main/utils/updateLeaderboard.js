// Path: DG-2.0/utils/updateLeaderboard.js

const fs = require('fs');
const { MessageEmbed } = require('discord.js');

module.exports = async (client) => {
    const playersPath = './data/players.json';
    if (!fs.existsSync(playersPath)) {
        console.error('Players file not found');
        return;
    }

    const players = JSON.parse(fs.readFileSync(playersPath));
    const sortedPlayers = Object.entries(players).sort((a, b) => b[1].balance - a[1].balance);

    const medals = ['🥇', '🥈', '🥉'];
    let leaderboardText = '';

    sortedPlayers.slice(0, 10).forEach(([id, data], index) => {
        const user = client.users.cache.get(id);
        const username = user ? `<@${id}>` : 'Unknown';
        const medal = medals[index] || `${index + 1}.`;
        leaderboardText += `${medal} ${username} - $${data.balance.toLocaleString()}\n`;
    });

    const embed = new MessageEmbed()
        .setTitle('🏆 **Leaderboard** 🏆')
        .setDescription(leaderboardText)
        .setColor('GOLD')
        .setFooter({ text: `Last updated: ${new Date().toLocaleString()}` });

    const leaderboardChannel = client.channels.cache.get(process.env.LEADERBOARD_CHANNEL_ID);
    if (leaderboardChannel) {
        const messages = await leaderboardChannel.messages.fetch({ limit: 10 });
        const botMessage = messages.find(msg => msg.author.id === client.user.id);
        if (botMessage) {
            await botMessage.edit({ embeds: [embed] });
        } else {
            await leaderboardChannel.send({ embeds: [embed] });
        }
    } else {
        console.error('Leaderboard channel not found');
    }
};
